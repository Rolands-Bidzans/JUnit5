package com.rolands;

import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;

import static org.junit.jupiter.api.Assertions.assertEquals;

@DisplayName("Test Math operations by Csv source")
public class UseExternalCsvSource {
    Calculator calculator;

    @BeforeAll
    static void setup() {
        System.out.println("Before all tests: prepare DB connection");
    }

    @AfterAll
    static void cleanup() {
        System.out.println("After All: close DB connection");
    }

    @BeforeEach
    void init() {
        this.calculator = new Calculator();
        System.out.println("Before each test: prepare test data");
    }

    @AfterEach
    void cleanupData() {
        System.out.println("After each test: clean up test data");
    }

    @DisplayName("Test integer Subtraction [minuend, subtrahend, expectedResult]")
    @ParameterizedTest
    @CsvFileSource(resources = "/integerSubtraction.csv")
    void integerSubtraction(int minuend, int subtrahend, int expectedResult) {
        //Arrange / Given


        // Act / When
        int actualResult = calculator.integerSubtraction(minuend, subtrahend);


        assertEquals(expectedResult, actualResult, () -> minuend +" - " + subtrahend + " should be " + expectedResult);
    }

}
