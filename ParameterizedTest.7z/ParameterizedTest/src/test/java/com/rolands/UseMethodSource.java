package com.rolands;

import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertEquals;

@DisplayName("Test Math operations by Method source")
public class UseMethodSource {
    Calculator calculator;

    @BeforeAll
    static void setup() {
        System.out.println("Before all tests: prepare DB connection");
    }

    @AfterAll
    static void cleanup() {
        System.out.println("After All: close DB connection");
    }

    @BeforeEach
    void init() {
        this.calculator = new Calculator();
        System.out.println("Before each test: prepare test data");
    }

    @AfterEach
    void cleanupData() {
        System.out.println("After each test: clean up test data");
    }

    @DisplayName("Test integer Subtraction [minuend, subtrahend, expectedResult]")
    @ParameterizedTest
    @MethodSource()
    void integerSubtraction(int minuend, int subtrahend, int expectedResult) {
        //Arrange / Given


        // Act / When
        int actualResult = calculator.integerSubtraction(minuend, subtrahend);


        assertEquals(expectedResult, actualResult, () -> minuend +" - " + subtrahend + " should be " + expectedResult);
    }

    private static Stream<Arguments> integerSubtraction() {
        return Stream.of(
                Arguments.of(6, 2, 4),
                Arguments.of(3, 2, 1),
                Arguments.of(7, 2, 5),
                Arguments.of(3, 3, 0)
        );

    }
}

//mvn clean install -DskipTests
//mvn package
//mvn clean test / mvn test
