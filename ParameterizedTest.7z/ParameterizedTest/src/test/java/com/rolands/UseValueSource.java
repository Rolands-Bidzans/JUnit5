package com.rolands;

import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@DisplayName("Test Math operations by Csv source")
public class UseValueSource {
    Calculator calculator;

    @BeforeAll
    static void setup() {
        System.out.println("Before all tests: prepare DB connection");
    }

    @AfterAll
    static void cleanup() {
        System.out.println("After All: close DB connection");
    }

    @BeforeEach
    void init() {
        this.calculator = new Calculator();
        System.out.println("Before each test: prepare test data");
    }

    @AfterEach
    void cleanupData() {
        System.out.println("After each test: clean up test data");
    }

    @DisplayName("Test integer Subtraction [minuend, subtrahend, expectedResult]")
    @ParameterizedTest
    @ValueSource(strings = {"Rolands", "Bidzans", "John"})
    void integerSubtraction(String firstName) {
        System.out.println(firstName);
        assertNotNull(firstName);
    }

}
