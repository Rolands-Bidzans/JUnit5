package com.rolands;

public class Calculator {

    public int integerDivision(int dividend, int divisor){
        return dividend / divisor;
    }

    public int integerSubtraction(int minuend, int subtrahend) {
        return minuend - subtrahend;
    }
}
