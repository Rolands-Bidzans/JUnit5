package com.rolands;

import org.junit.jupiter.api.*;

import static org.junit.jupiter.api.Assertions.assertEquals;

@DisplayName("Test Math operations by Csv source")
public class RepeatedTests {
    Calculator calculator;

    @BeforeEach
    void init() {
        this.calculator = new Calculator();
        System.out.println("Before each test: prepare test data");
    }

    @DisplayName("Test Integer Subtraction")
    @RepeatedTest(value=3, name="{displayName}, Repetition {currentRepetition} of {totalRepetitions}")
    void integerSubtraction(
            RepetitionInfo repeatedTestInfo,
            TestInfo testInfo) {
        System.out.println(testInfo.getTestMethod().get().getName());
        System.out.println(
                "Repetition Nr: #" + repeatedTestInfo.getCurrentRepetition()
                        + " of " + repeatedTestInfo.getTotalRepetitions());
        //Arrange / Given
        int minuend = 6;
        int subtrahend = 2;
        int expectedResult = 4;


        // Act / When
        int actualResult = calculator.integerSubtraction(minuend, subtrahend);


        assertEquals(expectedResult, actualResult, () -> minuend +" - " + subtrahend + " should be " + expectedResult);
    }

}
