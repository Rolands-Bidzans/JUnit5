package com.rolands;

import org.junit.jupiter.api.*;

@Order(3)
@TestMethodOrder(MethodOrderer.MethodName.class)
public class TestOrderedByName {
    Calculator calculator;

    @Test
    void testA(){
        System.out.println("Running test A");
    }

    @Test
    void testC(){
        System.out.println("Running test C");
    }

    @Test
    void testB(){
        System.out.println("Running test B");
    }

    @Test
    void testD(){
        System.out.println("Running test D");
    }

}

//mvn clean install -DskipTests
//mvn package
//mvn clean test / mvn test
