package com.rolands;

import org.junit.jupiter.api.*;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

@DisplayName("Test Math operations in Calculator class")
public class DemoTest {
    Calculator calculator;

    @BeforeAll
    static void setup() {
        System.out.println("Before all tests: prepare DB connection");
    }

    @AfterAll
    static void cleanup() {
        System.out.println("After All: close DB connection");
    }

    @BeforeEach
    void init() {
        this.calculator = new Calculator();
        System.out.println("Before each test: prepare test data");
    }

    @AfterEach
    void cleanupData() {
        System.out.println("After each test: clean up test data");
    }

    @Test
    @DisplayName("Test 6 / 2")
    void testIntegerDivision_WhenSixIsDividedByTwo_ShouldReturnThree() {
        //Arrange / Given
        int dividend = 6;
        int divisor = 2;
        int expected = 3;

        // Act / When
        int actualResult = calculator.integerDivision(dividend, divisor);

        // Assert / Then
        assertEquals(expected, actualResult, () -> dividend +" / " + divisor + " should be " + expected);
        //assert result == 3;
    }

    @Test
    @DisplayName("Division by Zero")
    void testIntegerDivision_WhenDividendIsDividedByZero_ShouldThrowArithmeticException() {
        // Arrange / Given
        int dividend = 6;
        int divisor = 0;
        String expectedExceptionMessage = "/ by zero";  // Corrected expected message

        // Act / When
        ArithmeticException actualException = assertThrows(ArithmeticException.class,
                () -> calculator.integerDivision(dividend, divisor),
                () -> "Division by zero should have thrown an exception"
        );

        // Assert / Then
        assertEquals(expectedExceptionMessage, actualException.getMessage(),
                () -> "Unexpected exception message");
    }

    @Disabled("Disabled for now")
    @Test
    @DisplayName("Test 6 - 2")
    void testIntegerSubstractionWithPositiveOperands() {
        //Arrange / Given
        int minuend = 6;
        int subtrahend = 2;
        int expectedResult = 4;

        // Act / When
        int actualResult = calculator.integerSubtraction(minuend, subtrahend);


        assertEquals(expectedResult, actualResult, () -> minuend +" - " + subtrahend + " should be " + expectedResult);
    }
}

//mvn clean install -DskipTests
//mvn package
//mvn clean test / mvn test
